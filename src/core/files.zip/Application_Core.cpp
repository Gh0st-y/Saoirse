// Application lifecycle, GLFW window, Vulkan instance/debug messenger/surface setup
//
// Part of the Application class split. See Application.h for the full
// class declaration - all methods below are Application:: members.
#include "Application.h"
#include <iostream>

void Application::run() 
{
    initWindow();
    initVulkan();
    mainLoop();
    cleanup();
}

#pragma region Initialization

// --- Init Window ---
void Application::initWindow() 
{
    glfwInit();

    // Tell GLFW not to create an OpenGL context
    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE); // we'll handle resizing properly later

    window = glfwCreateWindow(WIDTH, HEIGHT, "Saoirse", nullptr, nullptr);

    glfwSetWindowUserPointer(window, this);
    glfwSetCursorPosCallback(window, mouseCallback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
}

// --- Init Vulkan ---
void Application::initVulkan() {
    createInstance();
    setupDebugMessenger();
    createSurface();
    pickPhysicalDevice();
    createLogicalDevice();

    createCommandPool();

    createSwapChain();
    createImageViews();

    createRenderPass();

    createFrameDescriptorSetLayout();   
    createObjectDescriptorSetLayout();  
    createGBufferDescriptorSetLayout();

    createShadowRenderPass();
    createShadowResources();
    createSpotShadowResources();
    createPointShadowResources();
    createShadowPipeline();
    createPointShadowPipeline();

    createGeometryPipeline();   
    createLightingPipeline();

    createDepthResources();
    createGBufferResources();
    createFramebuffers();

    createFrameUniformBuffer();

    scene.gameObjects.reserve(10);   // safeguard against reference invalidation, per the note above

    Mesh* monkeyMesh = loadMesh("assets/models/monkey.obj");
    Mesh* floorMesh = loadMesh("assets/models/floor.obj");
    Texture* monkeyTexture = loadTexture("assets/textures/fabric.png");
    Texture* floorTexture = loadTexture("assets/textures/tile.png");

    Mesh* boxMesh = loadMesh("assets/models/box.obj");
    Texture* boxTexture = loadTexture("assets/textures/box.png");

    createDescriptorPool();   // must come before createGameObject(), since it allocates descriptor sets from this pool
    createFrameDescriptorSet();
    createGBufferDescriptorSet();

    GameObject& box = scene.addGameObject(boxMesh, boxTexture);
    box.rotation = glm::vec3(glm::radians(90.0f), 0.0f, 0.0f);
    box.position = glm::vec3(3.0f, 0.0f, 0.0f);
    createGameObjectResources(box);

    GameObject& floor = scene.addGameObject(floorMesh, floorTexture);
    floor.rotation = glm::vec3(glm::radians(90.0f), 0.0f, 0.0f);
    floor.position = glm::vec3(0.0f, 0.0f, -3.0f);
    createGameObjectResources(floor);

    GameObject& monkey = scene.addGameObject(monkeyMesh, monkeyTexture);
    monkey.rotation = glm::vec3(glm::radians(90.0f), 0.0f, 0.0f);
    monkey.position = glm::vec3(-3.0f, 0.0f, 0.0f);
    createGameObjectResources(monkey);

    //GameObject& monkey2 = scene.addGameObject(monkeyMesh, monkeyTexture);
    //monkey2.position = glm::vec3(4.0f, 0.0f, 0.0f);
    //createGameObjectResources(monkey2);

    //monkey2.setParent(&monkey);

    Light& sun = scene.addLight(LightType::Directional);
    sun.direction = glm::normalize(glm::vec3(-0.5f, -0.5f, -1.0f));
    sun.color = glm::vec3(0.3f, 0.3f, 0.35f);

    Light& lamp = scene.addLight(LightType::Point);
    lamp.position = glm::vec3(2.0f, 2.0f, 4.0f);
    lamp.color = glm::vec3(0.0f, 0.0f, 1.0f);
    lamp.attenuation = glm::vec3(1.0f, 0.09f, 0.032f);

    //Light& spotlight = scene.addLight(LightType::Spot);
    //spotlight.position = glm::vec3(-2.0f, -2.0f, 3.0f);
    //spotlight.direction = glm::normalize(glm::vec3(0.5f, 0.5f, -0.5f));
    //spotlight.color = glm::vec3(1.0f, 0.0f, 0.0f);
    //spotlight.attenuation = glm::vec3(1.0f, 0.09f, 0.032f);
    //spotlight.innerConeAngleDegrees = 12.5f;
    //spotlight.outerConeAngleDegrees = 17.5f;

    createCommandBuffer();
    createSyncObjects();
}

#pragma endregion

// --- Main Loop ---
void Application::mainLoop() 
{
    while (!glfwWindowShouldClose(window)) {
        float currentFrameTime = static_cast<float>(glfwGetTime());
        float deltaTime = currentFrameTime - lastFrameTime;
        lastFrameTime = currentFrameTime;

        glfwPollEvents();
        processInput(deltaTime);
        drawFrame();
    }

    vkDeviceWaitIdle(device);
}

// --- Cleanup ---
void Application::cleanup()
{
    vkDestroyPipeline(device, shadowPipeline, nullptr);
    vkDestroyPipelineLayout(device, shadowPipelineLayout, nullptr);
    vkDestroyPipeline(device, pointShadowPipeline, nullptr);
    vkDestroyPipelineLayout(device, pointShadowPipelineLayout, nullptr);

    vkDestroyRenderPass(device, pointShadowRenderPass, nullptr);

    for (int i = 0; i < MAX_POINT_LIGHTS; i++) {
        vkDestroyImageView(device, pointShadowCubemapViews[i], nullptr);
        for (int face = 0; face < 6; face++) {
            vkDestroyFramebuffer(device, pointShadowFramebuffers[i][face], nullptr);
            vkDestroyImageView(device, pointShadowFaceViews[i][face], nullptr);
        }
        vkDestroyImage(device, pointShadowCubemaps[i], nullptr);
        vkFreeMemory(device, pointShadowMemories[i], nullptr);
    }

    vkDestroySampler(device, pointShadowSampler, nullptr);

    for (int i = 0; i < MAX_SPOT_LIGHTS; i++) {
        vkDestroyFramebuffer(device, spotShadowFramebuffers[i], nullptr);
        vkDestroyImageView(device, spotShadowViews[i], nullptr);
        vkDestroyImage(device, spotShadowImages[i], nullptr);
        vkFreeMemory(device, spotShadowMemories[i], nullptr);
    }
    vkDestroySampler(device, spotShadowSampler, nullptr);

    for (auto& obj : scene.gameObjects) {
        vkDestroyBuffer(device, obj->uniformBuffer, nullptr);
        vkFreeMemory(device, obj->uniformBufferMemory, nullptr);
    }

    for (auto& mesh : meshes) destroyMesh(mesh.get());
    for (auto& texture : textures) destroyTexture(texture.get());

    vkDestroyDescriptorPool(device, descriptorPool, nullptr);
    vkDestroyBuffer(device, frameUniformBuffer, nullptr);
    vkFreeMemory(device, frameUniformBufferMemory, nullptr);

    vkDestroyDescriptorSetLayout(device, gBufferDescriptorSetLayout, nullptr);
    vkDestroyDescriptorSetLayout(device, frameDescriptorSetLayout, nullptr);
    vkDestroyDescriptorSetLayout(device, objectDescriptorSetLayout, nullptr);

    vkDestroyImageView(device, gBufferPositionView, nullptr);
    vkDestroyImage(device, gBufferPosition, nullptr);
    vkFreeMemory(device, gBufferPositionMemory, nullptr);

    vkDestroyImageView(device, gBufferNormalView, nullptr);
    vkDestroyImage(device, gBufferNormal, nullptr);
    vkFreeMemory(device, gBufferNormalMemory, nullptr);

    vkDestroyImageView(device, gBufferAlbedoView, nullptr);
    vkDestroyImage(device, gBufferAlbedo, nullptr);
    vkFreeMemory(device, gBufferAlbedoMemory, nullptr);

    vkDestroyImageView(device, depthImageView, nullptr);
    vkDestroyImage(device, depthImage, nullptr);
    vkFreeMemory(device, depthImageMemory, nullptr);

    for (int i = 0; i < 4; i++) {
        vkDestroyFramebuffer(device, cascadeFramebuffers[i], nullptr);
        vkDestroyImageView(device, cascadeImageViews[i], nullptr);
        vkDestroyImage(device, cascadeImages[i], nullptr);
        vkFreeMemory(device, cascadeImageMemories[i], nullptr);
    }

    vkDestroySampler(device, shadowMapSampler, nullptr);

    vkDestroyRenderPass(device, shadowRenderPass, nullptr);

    vkDestroySemaphore(device, imageAvailableSemaphore, nullptr);
    for (auto sem : renderFinishedSemaphores) {
        vkDestroySemaphore(device, sem, nullptr);
    }
    vkDestroyFence(device, inFlightFence, nullptr);

    vkDestroyCommandPool(device, commandPool, nullptr);

    for (auto framebuffer : swapChainFramebuffers) {
        vkDestroyFramebuffer(device, framebuffer, nullptr);
    }

    vkDestroyPipeline(device, geometryPipeline, nullptr);
    vkDestroyPipelineLayout(device, geometryPipelineLayout, nullptr);
    vkDestroyPipeline(device, lightingPipeline, nullptr);
    vkDestroyPipelineLayout(device, lightingPipelineLayout, nullptr);

    vkDestroyRenderPass(device, renderPass, nullptr);

    for (auto imageView : swapChainImageViews) {
        vkDestroyImageView(device, imageView, nullptr);
    }

    vkDestroySwapchainKHR(device, swapChain, nullptr);
    vkDestroyDevice(device, nullptr);

    if (enableValidationLayers) {
        auto func = (PFN_vkDestroyDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance, "vkDestroyDebugUtilsMessengerEXT");
        if (func != nullptr) func(instance, debugMessenger, nullptr);
    }

    vkDestroySurfaceKHR(instance, surface, nullptr);
    vkDestroyInstance(instance, nullptr);

    glfwDestroyWindow(window);
    glfwTerminate();
}

// --- Create Instance ---
void Application::createInstance() 
{
    if (enableValidationLayers && !checkValidationLayerSupport()) {
        throw std::runtime_error("validation layers requested, but not available!");
    }

    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "MyEngine";
    appInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.pEngineName = "No Engine";
    appInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.apiVersion = VK_API_VERSION_1_3;

    VkInstanceCreateInfo createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    createInfo.pApplicationInfo = &appInfo;

    auto extensions = getRequiredExtensions();
    createInfo.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    createInfo.ppEnabledExtensionNames = extensions.data();

    if (enableValidationLayers) {
        createInfo.enabledLayerCount = static_cast<uint32_t>(validationLayers.size());
        createInfo.ppEnabledLayerNames = validationLayers.data();
    }
    else {
        createInfo.enabledLayerCount = 0;
    }

    if (vkCreateInstance(&createInfo, nullptr, &instance) != VK_SUCCESS) {
        throw std::runtime_error("failed to create Vulkan instance!");
    }
}

// --- Debug Callback ---
static VKAPI_ATTR VkBool32 VKAPI_CALL debugCallback(
    VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,
    VkDebugUtilsMessageTypeFlagsEXT messageType,
    const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,
    void* pUserData) {

    std::cerr << "[Validation] " << pCallbackData->pMessage << std::endl;
    return VK_FALSE;
}

// --- Create Debug Utils Messenger EXT ---
VkResult CreateDebugUtilsMessengerEXT(VkInstance instance,
    const VkDebugUtilsMessengerCreateInfoEXT* pCreateInfo,
    const VkAllocationCallbacks* pAllocator,
    VkDebugUtilsMessengerEXT* pDebugMessenger) {

    auto func = (PFN_vkCreateDebugUtilsMessengerEXT)vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT");
    if (func != nullptr) {
        return func(instance, pCreateInfo, pAllocator, pDebugMessenger);
    }
    return VK_ERROR_EXTENSION_NOT_PRESENT;
}

// --- Setup Debug Messenger ---
void Application::setupDebugMessenger() 
{
    if (!enableValidationLayers) return;

    VkDebugUtilsMessengerCreateInfoEXT createInfo{};
    createInfo.sType = VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT;
    createInfo.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT
        | VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
    createInfo.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT
        | VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT
        | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
    createInfo.pfnUserCallback = debugCallback;

    if (CreateDebugUtilsMessengerEXT(instance, &createInfo, nullptr, &debugMessenger) != VK_SUCCESS) {
        throw std::runtime_error("failed to set up debug messenger!");
    }
}

// --- Create Surface ---
void Application::createSurface() 
{
    if (glfwCreateWindowSurface(instance, window, nullptr, &surface) != VK_SUCCESS) {
        throw std::runtime_error("failed to create window surface!");
    }
}

// --- Check Validation Layer Support ---
bool Application::checkValidationLayerSupport() 
{
    uint32_t layerCount;
    vkEnumerateInstanceLayerProperties(&layerCount, nullptr);

    std::vector<VkLayerProperties> availableLayers(layerCount);
    vkEnumerateInstanceLayerProperties(&layerCount, availableLayers.data());

    for (const char* layerName : validationLayers) {
        bool layerFound = false;
        for (const auto& layerProperties : availableLayers) {
            if (strcmp(layerName, layerProperties.layerName) == 0) {
                layerFound = true;
                break;
            }
        }
        if (!layerFound) return false;
    }
    return true;
}

// --- Get Required Extensions ---
std::vector<const char*> Application::getRequiredExtensions() 
{
    uint32_t glfwExtensionCount = 0;
    const char** glfwExtensions = glfwGetRequiredInstanceExtensions(&glfwExtensionCount);

    std::vector<const char*> extensions(glfwExtensions, glfwExtensions + glfwExtensionCount);

    if (enableValidationLayers) {
        extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);
    }

    return extensions;
}
